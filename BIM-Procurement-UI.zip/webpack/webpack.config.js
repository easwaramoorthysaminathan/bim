const HtmlWebPackPlugin = require("html-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const Dotenv = require("dotenv-webpack");
const path = require("path");

module.exports = {
  devtool: "source-map",
  //context:path.join(process.cwd(), 'app'),
  entry: {
    app: path.join(process.cwd(), "app/appmain.js")
  },
  output: {
    pathinfo: true,
    path: path.join(process.cwd(), "dist"),
    filename: "static/js/appbundle.js",
    chunkFilename: "static/js/chunk-[name].js",
    publicPath: "/"
  },
  devServer: {
    contentBase: path.join(process.cwd(), "public"),
    port: 3001,
    historyApiFallback: true,
    hot: true
    //open: true,
    //openPage: '',
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        loader: "babel-loader",
        options: {
          presets: ["env"],
          plugins: [require("babel-plugin-transform-object-rest-spread")]
        }
      },
      {
        test: /\.css|.scss$/,
        use: [
          { loader: MiniCssExtractPlugin.loader },
          {
            loader: "css-loader",
            options: {
              importLoaders: 1,
              minimize: false
              //localIdentName: 'static/css/[name].css'
            }
          },
          {
            loader: "resolve-url-loader"
          },

          {
            loader: "sass-loader",
            options: {
              includePaths: [path.join(process.cwd(), "assets/saas")],
              sourceMap: true
            }
          }
        ]
      },
      {
        test: /\.(png|woff|woff2|eot|ttf|svg|jpg|gif)$/,
        loader: "url-loader",
        include: [path.join(process.cwd(), "assets/css")],
        options: {
          limit: 1000,
          name: "static/images/[name].[ext]"
        }
      },
      {
        test: /\.(jpg|png|svg)$/,
        loader: "file-loader",
        include: [path.join(process.cwd(), "assets/images")],
        options: {
          //useRelativePath:true,
          name: "static/images/[name].[ext]"
        }
      }
    ]
  },
  resolve: {
    modules: [
      path.join(process.cwd(), "app"),
      path.join(process.cwd(), "node_modules")
    ],
    extensions: [".js", ".jsx"],
    alias: {
      components: path.resolve("app/components"),
      utils: path.resolve("app/utils"),
      assets: path.resolve("assets")
    }
  },
  plugins: [
    new Dotenv({ path: "./webpack/dev.env" }),
    new HtmlWebPackPlugin({
      inject: true,
      template: path.join(process.cwd(), "public/index.html"),
      favicon: path.join(process.cwd(), "assets/images/favicon.ico"),
      chunksSortMode: "none"
      //filename: "./index.html"
      //title: 'Output Management'
    }),
    new MiniCssExtractPlugin({
      filename: "static/css/[name].css", // : '[name].[hash].css',
      chunkFilename: "static/css/chunk-[id].css" // : '[id].[hash].css',
    })
  ]
};
