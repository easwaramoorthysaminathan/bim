import React from 'react'
import Loadable from 'react-loadable';
import queryString from './querystring';
import {F_KEY,S_KEY,C_KEY,O_KEY,P_KEY,CATEGORY,LIMIT,COOKIE_ID,USER_TKEY,AUTH_KEY,RFRESH_TOKEN,EXPIRES_AT} from 'utils/constants';
import {setToCache,getFromCache,removeFromCache} from './querystring';

const dynaParamSep = ':';

function loading(props) {
  //console.log('loader------');
  if (props.error) {
    return <div>Error! <button onClick={ props.retry }>Retry</button></div>;
  } else if (props.timedOut) {
    return <div>Taking a long time... <button onClick={ props.retry }>Retry</button></div>;
  } else if (props.pastDelay) {
    return <div>Loading...</div>;
  } else {
    return null;
  }
}

export function isInViewport(elem) {
  const padding = 25;
  var bounding = elem.getBoundingClientRect();
  //console.log(bounding);
  return (
      (bounding.top + padding) >= 0 &&
      (bounding.left + padding) >= 0 &&
      (bounding.bottom - padding) <= (window.innerHeight || document.documentElement.clientHeight) &&
      (bounding.right - padding) <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

export function getUID(){
  let cid = queryString.getFromCache(COOKIE_ID);
  !cid && (cid=new Date().getTime().toString(16).toUpperCase()) && queryString.setToCache(COOKIE_ID,cid);
  return cid;
}

export function validUToken(refresh){
  let d = new Date().getTime();
  let t = getFromCache(USER_TKEY) || null;
  if(t){
    let e = parseInt(getFromCache(EXPIRES_AT)||'0');
    if(e < d){
      t = null;
      refresh && app.events.trigger(RFRESH_TOKEN);
    }
  }
  return t;
}

export function gotoUrl(url,history){
  history = history || app.history;
  if(history){
    history.push(url)
  }
  else{
    window.location.href = url;
  }  
}
export function normName(name){
  return name.trim().replace(/\s+/g, "-").replace(/[^a-z0-9-]/gmi, "");
}
export function loadableComp(compId,loaderfn=loading){
  return Loadable({
    loader: () => import('components/'+compId),
    loading: loaderfn,
    compId:compId
  });
}

export function getQuery(querystr,fromPage=false){
  //const queryString = require('components/querystring');
  return fromPage?queryString.parseUrl(window.location.href).query:queryString.parse(querystr);
}

export function getUpdatedPageUrl(key,value,query,url){
  query = query || queryString.parseUrl(window.location.href).query;
  query[key] = value;

  return getPageUrlWithQuery(url,query);
}

export function getPageUrlWithQuery(url,query){
  let q = queryString.stringify(query,{removeEmptyValueKeys:true});
  return (url?(url+(q?'?':'')):'')+q;
}

export function resolveApiUrl(urlKey,params={},appendParams=true){
  return resolveUrl((app.apis[urlKey] || urlKey),params,app.apis.baseurl,appendParams)
}

export function resolveRouterPath(pathKey,params={}){
  return resolveUrl((app.routesMap[pathKey]? app.routesMap[pathKey].path:pathKey),params,null,false);
}

export function getCurrentPathWithQuery(params={}){
  let url = resolveRouterPath(app.pageInfo.path,params,null,false);
  return getPageUrlWithQuery(url,app.pageInfo.query);
}

function resolveUrl(uri,params={},baseurl,appendParams=true){
  //if(!app.apis[urlKey]) return urlKey;
  params = {...app.pageParams,...app.pageInfo.params,...params};
  if(params['normName'] && params[params['normName']]){
    params[params['normName']] = normName(params[params['normName']]);
    delete params['normName'];
  }
  let url = [];
  baseurl && url.push(baseurl);
  if(uri.startsWith('http://')){
    uri = uri.substring(6);
    url = ['http://'];
  }
  for (let urlPart of uri.split('/')) {
      let urlPart2 = urlPart.slice(1);
      if(urlPart.charAt(0) == dynaParamSep && params[urlPart2]){
          urlPart = params[urlPart2]+'';
          delete params[urlPart2];
      }
      urlPart && urlPart.length && url.push(urlPart);
  } 
  
  let p = appendParams?Object.keys(params).map(key => {
      let v = params[key];
      return v? (key+'='+v):'';
  }).filter(x => x.length > 0).join('&'):'';
  url = ((baseurl || uri.startsWith('http://'))?'':'/') + url.join('/') + (p.length?('?'+p):'');
  return url;
}


export function translate(resourceKey,searchQuery){
  return app.translations[resourceKey] || resourceKey;
}

export function setPageTitle(title){
  return document.title = 'Noc Noc Products: '+title;
}

export function getSearchQuery(filters,query,jsonStr){
  let sq = {...app.pageParams};
  if(query[C_KEY]){
    let ctgs = query[C_KEY].split(':'); 
    filters = {ctgr:{field:ctgs[0],type:CATEGORY,codes:[ctgs[1]]},...filters};
  }
  let fq = Object.keys(filters).map(k=>{
      let v = filters[k];
      return (!v || !v.codes.length)?'':v;
  }).filter(x => x && x.codes); 
  if(fq.length) sq['f'] = jsonStr?JSON.stringify(fq):fq;
  if(query[S_KEY]){
    let q = {term:query[S_KEY],fields:app.queryFields};
    sq['q'] = jsonStr?JSON.stringify(q):q;
  }
  if(query[O_KEY] || app.defualtSort){
    let srder = (query[O_KEY] || app.defualtSort).split(':'); 
    sq.sort = {field:srder[0],order:(srder[1]||'')};
  }
  if(query[LIMIT]){
    sq[LIMIT] = parseInt(query[LIMIT]);
  }
  sq.page = query[P_KEY] || 1;
  return sq;
}

export function getStaticContentUrl(uri,host)
{
   host = host || app.staticContentHost;
   return !uri || uri.startsWith('http://') || uri.startsWith('https://')?uri:host+(uri.startsWith('/')?'':'/')+uri;
}

