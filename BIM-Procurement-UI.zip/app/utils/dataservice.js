import {resolveApiUrl,validUToken} from 'utils/common';
import {METHOD_GET,METHOD_POST,METHOD_PUT,METHOD_DELETE,CACHE,USER_TKEY,AUTH_KEY} from 'utils/constants';
import {setToCache,getFromCache,removeFromCache} from './querystring';
const defaultPostOpt = {
    method: METHOD_POST,
    mode: "cors",
    headers: {
        "Content-Type": "application/json; charset=utf-8"
    }
}
class DataService {

    // async function
    async deleteRequest(urlkey,params={},options={}){
      //options = {...options,method:METHOD_DELETE};
      return this.getRequest(urlkey,params,{...options,method:METHOD_DELETE});
    }
    async getRequest(urlkey,params={},options={}){
      let data = {};
      if(app.apis){
        data = await this._sendRequest(urlkey,params,options);
      }
      else{
        data = await app.apiConfig.then(res=>{
              return this._sendRequest(urlkey,params,options);
          })
      }
      console.log('-------urlkey---------'+urlkey);
      return data;
    }

    async postRequest(urlkey,params={},options={}){
        if(process.env.POST_METHOD == METHOD_GET){
          return this.getRequest(urlkey,params,{...options,method:METHOD_GET});
        } 
        let data = {};
        options = {...defaultPostOpt,...options};
        //options['body'] = JSON.stringify(params);
        if(app.apis){
          data = await this._sendRequest(urlkey,params,options);
        }
        else{
          data = await app.apiConfig.then(res=>{
                return this._sendRequest(urlkey,params,options);
            })
        }
        console.log('-------urlkey---------'+urlkey);
        return data;
      }

    async _sendRequest(urlkey,params,bodyOpt={method:METHOD_GET,mode: "cors",}){
        let cacheKey = params[CACHE];
        delete params[CACHE];
        params = {...app.pageParams,...params};
        let paramsToBody = bodyOpt.method == METHOD_POST || bodyOpt.method == METHOD_PUT || !!bodyOpt.paramsToBody;
        let url = resolveApiUrl(urlkey,params,!paramsToBody);
        if(paramsToBody){
            bodyOpt['body'] = JSON.stringify(params);
        }
        let authToken = validUToken(!params.newToken);
        if(params.auth && authToken){
            bodyOpt.headers = bodyOpt.headers || {};
            bodyOpt.headers[AUTH_KEY] = authToken;
        }
        console.log(cacheKey+'-------_sendRequest url---------'+url);
        let data = await (await (fetch(url,bodyOpt)
        .then(res => {
          let jres = res.json();
          cacheKey && setToCache(cacheKey,jres);
          return jres
        })
        .catch(err => {
          console.log('Error in data service: ', err);
          cacheKey && removeFromCache(cacheKey);
        })
      ))
      return data
    }
}
    
export default new DataService()