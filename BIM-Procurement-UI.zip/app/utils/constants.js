export const BASE_API_URL2 = "http://18.218.120.176/";
export const BASE_API_URL = 'http://18.218.120.176/api.php/records/';
export const MATHCER_API_URL="http://localhost:8080";
export const METHOD_GET = 'GET';
export const METHOD_POST = 'POST';
export const METHOD_PUT = 'PUT';
export const METHOD_DELETE = 'DELETE';

//events
export const WIN_CLICK = 'click';
export const WIN_RESIZE = 'resize';
export const WIN_SCROLL = 'scroll';

export const LANG_SWITCHED = 'lang:switched';
export const SEARCH = 'search:g';
export const CLR_SEARCH = 'search:clr';
export const CATEGORY_DATA = 'search:category';
export const FILTER_UPDATED = 'f:updated';
export const MENU_CLICKED = 'm:clicked';
export const PATH_CHANGED = 'path:changed';
export const UPDATECART = 'cart:update';
export const RFRESH_CART = 'cart:refresh';
export const FETCH_CART_ITEMS = 'cart:fetchall';
export const MERGE_CART_ITEMS = 'cart:merge';
export const SUB_CART_ITEMS = 'cart:sendall';
export const GOTO_URL = 'url:switch';
export const USER_SIGNIN = 'user:signin';
export const USER_SIGNOUT = 'user:signout';
export const RFRESH_TOKEN = 'usertoken:refresh';
export const TOGGLE_INSTALLATION = 'installation:toggle';

export const ADD = 'add';
export const CACHE = 'addToCache';
export const EDIT = 'edit';
export const DELETE = "delete";
export const DELETE_ALL = "deleteall";
export const ACTIONS = { ADD, EDIT, DELETE, DELETE_ALL };
export const HOME_TITLE = 'Home';
export const LANG = 'lang';
export const CATEGORY = 'category';
export const PARAMS = 'params';
export const READY = "ready";
export const PROCESSING = "processing";
export const WAIT = "wait";
export const STATUS = { READY, WAIT, PROCESSING };
export const F_KEY = 'fq';
export const S_KEY = 'st';
export const C_KEY = 'ct';
export const O_KEY = 'so';
export const P_KEY = 'pg';
export const S_USER = 'su';
export const LIMIT = 'limit';
export const P_ITEMS_LIMIT = 8;
export const USER_TKEY = 'atfu';
export const EXPIRES_AT = 'expt';
export const AUTH_KEY = 'Authorization';
export const RES_SCREEN_MAX_WIDTH = 990;

//routes
export const LANDING = 'landing';
export const PRODUCTS = 'products';
export const PRODUCT = 'product';
export const COMPARE = 'compare';
export const PATH_PREFIX = '/by/';

//ba
export const PAGE = 'page';
export const PREV_PAGE = 'prevPage';
export const ACTION_AREA = 'area';
export const ATTR_TYPE = 'attrType';
export const ATTR_VALUE = 'attrValue';
export const BA_NOTE = 'note';
export const PAGE_NAV = 'Page Navigation';
export const PRODUCT_VIEWED = 'Products Viewed';
export const PAGE_ACTION = 'action';
export const DATE_TIME = 'datetime';
export const COOKIE_ID = 'userCId';
export const PAGE_NO = 'pageNo';
export const ITEM_METRIX = 'item_metrix';
export const SHARED_By_USER = 'sharedByUser';
export const BROWSER_NAME = 'browser';
export const DEVICE_DETAILS = 'deviceDetails';
export const FLTR_ATTR = 'filter attribute';
export const BA_SEPARATOR = ',';
export const BA_ACTION_QC = 'Quantity Changed';
export const BA_ACTION_AC = 'Add to Cart';
export const BA_ACTION_RFC = 'Removed from cart';
export const CART_QVIEW = 'Cart Quickview';
export const QUANTITY = 'quantity';


