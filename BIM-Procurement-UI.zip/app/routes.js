const routes = [
  {
    name: "landing",
    path: "/home",
    samplePath: "/home",
    componentId: "home",
    title: "Home",
    exact: true
  },
  {
    name: "projecttabs",
    path: "/projects",
    samplePath: "/projects",
    componentId: "projecttabs",
    title: "Projects",
    exact: true
  },
  {
    name: "BOQ",
    path: "/boqs",
    samplePath: "/boqs",
    componentId: "boqtabs",
    title: "BOQS",
    exact: false
  },
  {
    name: "PR",
    path: "/prs",
    samplePath: "/prs",
    componentId: "boqtabs",
    title: "BOQS",
    exact: false
  },
  {
    name: "PO",
    path: "/pos",
    samplePath: "/pos",
    componentId: "potabs",
    title: "Purchase Orders",
    exact: false
  },
  {
    name: "GR",
    path: "/grs",
    samplePath: "/grs",
    componentId: "grtabs",
    title: "Goods Receipt",
    exact: false
  }
];

export default routes;
