import React from "react";
import Grdetails from "./grdetails"
import Grlist from "./grlist"
import GrCreate from "./grcreate";
import Podetails from "./podetails";

class Grtabs extends React.Component {
    constructor(props) {
        console.log("BOQTAbs");
        console.log(props);
        super(props);
        this.state = {
            selectedGrForEdit: null,
            createGRMode: false,
            props: props
        };
        this.onGrListMenuClick = this.onGrListMenuClick.bind(this);
        this.onGrDetailTabClick = this.onGrDetailTabClick.bind(this);
        this.onGrCreateTabClick = this.onGrCreateTabClick.bind(this);
        this.onPoDetailTabClick = this.onPoDetailTabClick.bind(this);
        this.onGrRowClick = this.onGrRowClick.bind(this);
        this.onGrCreateClick = this.onGrCreateClick.bind(this);
        this.onPoViewClick = this.onPoViewClick.bind(this);
    }
    onGrDetailTabClick() {
        this.setState({
            selectedPOForEdit: null, createGRMode: false, selectedPOForEdit: null
        });
    }
    onGrCreateTabClick() {
        this.setState({
            selectedGrForEdit: null, selectedPOForEdit: null
        });
    }
    onPoDetailTabClick() {

    }
    onGrListMenuClick() {
        this.setState({
            selectedGrForEdit: null, selectedPOForEdit: null, createGRMode: false, selectedPOForEdit: null
        });
    }
    onGrCreateClick() {
        this.setState({ createGRMode: true, selectedPOForEdit: null, selectedGrForEdit: null });
    }
    onPoViewClick(pono) {
        this.setState({ selectedPOForEdit: pono });
    }
    onGrRowClick(pRow) {
        this.setState({
            selectedGrForEdit: pRow.goods_receipt_number,
            createGRMode: false,
            selectedPOForEdit: null
        });
    }
    render() {
        return (<React.Fragment>
            <nav>
                <div className="nav nav-tabs" id="nav-tab" role="tablist">
                    <a className={"nav-item nav-link  p-3 " + (this.state.selectedGrForEdit == null && this.state.createGRMode == false && this.state.selectedPoForEdit == null ? 'active' : '')} id="nav-projectlist-tab" data-toggle="tab" href="#nav-projectlist"
                        role="tab" aria-controls="nav-home" aria-selected="true" onClick={this.onGrListMenuClick}>GR List
                    </a>
                    {this.state.selectedGrForEdit != null ? (
                        <a className="nav-item nav-link  p-3 {{this.state.selectedGrForEdit == null?'active':''}}" id="nav-boq-tab" data-toggle="tab" href="#nav-boq" role="tab"
                            aria-controls="nav-boq" aria-selected="true" style={{ display: 'block' }} onClick={this.onGrDetailTabClick}>{this.state.selectedGrForEdit}
                        </a>) : ('')}

                    {this.state.createGRMode == true ? (
                        <a className="nav-item nav-link  p-3 active" id="nav-boq-tab" data-toggle="tab" href="#nav-boq" role="tab"
                            aria-controls="nav-boq" aria-selected="true" style={{ display: 'block' }} onClick={this.onGrCreateTabClick}>Create GR
                        </a>) : ('')}

                    {this.state.selectedPOForEdit != null ? (
                        <a className="nav-item nav-link  p-3 active" id="nav-boq-tab" data-toggle="tab" href="#nav-boq" role="tab"
                            aria-controls="nav-boq" aria-selected="true" style={{ display: 'block' }} onClick={this.onPoDetailTabClick}>{this.state.selectedPOForEdit}
                        </a>) : ('')}
                </div>
            </nav>
            <div className="tab-content p-3" id="nav-tabContent">
                {(() => {
                    if (this.state.selectedPOForEdit != null) {
                        return (
                            <Podetails selectedPoForEdit={this.state.selectedPOForEdit} />
                        )
                    } else if (this.state.selectedGrForEdit != null && this.state.createGRMode != true) {
                        return (
                            <Grdetails selectedGrForEdit={this.state.selectedGrForEdit} onPoViewClick={this.onPoViewClick} />
                        )
                    } else if (this.state.createGRMode) {
                        return (
                            <GrCreate onGrCreateClick={this.onGrCreateClick} onPoViewClick={this.onPoViewClick} />
                        )
                    } else {
                        return (
                            <Grlist onGrRowClick={this.onGrRowClick} onGrCreateClick={this.onGrCreateClick} />
                        )
                    }
                })()}
            </div></React.Fragment>);
    }
}

export default Grtabs;