import React from "react";

import DashboardPanel from "./dashboard";

import { Link } from "react-router-dom";
class HomePage extends React.Component {
  render() {
    return (
      <div className="content-box">
        <div className="content-panel pg-dashboard">
          <DashboardPanel />
        </div>
      </div>
    );
  }
}

export default HomePage;
