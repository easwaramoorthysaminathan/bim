import React from "react";
import logo from "assets/images/logo-scg.jpg";
import LoggedIn from "./loggedin";

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.gotoHome = this.gotoHome.bind(this);
  }
  gotoHome() {
    app.events.trigger(GOTO_URL, { routerKey: "landing" });
  }
  componentDidMount() {
    console.log("-----header mouted------");
  }
  render() {
    return (
      <React.Fragment>
        <header className="header-panel d-flex ">
          <div className=" container d-flex  ">
            <div class="logo justify-content-center">
              <a
                href="dashboard"
                title="SCG"
                class="
                        text-center  align-self-center d-block"
              >
                <i class="icon-SCG d-block" />
                <label class="d-block">Sprocurement</label>
              </a>
            </div>
            <div className="header-items d-flex justify-content-end">
              <LoggedIn />
            </div>
          </div>
        </header>
      </React.Fragment>
    );
  }
}

export default Header;
