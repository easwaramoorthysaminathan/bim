import React, { Component } from "react";
import updatesprofileimg from "assets/images/media-img1.jpg";

class CardUpdates extends Component {
  render() {
    return (
      <li className="media shadow-box p-3 m-3">
        <img
          className="mr-3"
          src={updatesprofileimg}
          alt="Generic placeholder image"
        />
        <div className="media-body">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed co
          <a href="#" className="text-right  d-block">
            Read more...
          </a>
        </div>
      </li>
    );
  }
}

export default CardUpdates;
