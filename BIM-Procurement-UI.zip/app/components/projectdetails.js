import React from "react";
import { BASE_API_URL, BASE_API_URL2 } from "../utils/constants";
import { ClipLoader } from 'react-spinners';

class Projectdetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedBOQ: null,
            selectedPR: null,
            selectedTab: 'boq',
            props: props,
            projectDetails: { boq: [] }
        };
        this.onBoqRowClick = this.onBoqRowClick.bind(this);
        this.onPrRowClick = this.onPrRowClick.bind(this);
        this.onBoqTabClick = this.onBoqTabClick.bind(this);
        this.onPrTabClick = this.onPrTabClick.bind(this);
        this.onUploadClick = this.onUploadClick.bind(this);
        this.getProjectDetails = this.getProjectDetails.bind(this);
        this.onFileChange = this.onFileChange.bind(this);
    }
    onFileChange() {
        this.setState({ 'fileName': this.uploadInput.files[0].name });
    }
    onUploadClick() {
        this.setState({ uploadInProgress: true });
        const data = new FormData();
        data.append('fileToUpload', this.uploadInput.files[0]);

        data.append('project_id', this.props.selectedProjectForEdit);
        data.append('customer_id', 1);
        var self = this;
        fetch(BASE_API_URL2 + '/boqreader.php', {
            method: 'POST',
            body: data,
        }).then(function () {
            self.setState({ uploadInProgress: false });
            self.getProjectDetails();
        }).catch(function (error) {
            self.setState({ uploadInProgress: false });
            self.getProjectDetails();
        });
    }
    onBoqRowClick(item) {
        this.state.props.onBoqRowClick(item);
    }
    onPrRowClick(item) {
        this.state.props.onPrRowClick(item);
    }
    onBoqTabClick() {
        this.setState({
            selectedTab: 'boq'
        });
    }
    onPrTabClick() {
        this.setState({
            selectedTab: 'pr'
        });
    }
    getProjectDetails() {
        fetch(BASE_API_URL + "/project/" + this.props.selectedProjectForEdit + "?join=boq,boq_items")
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        isLoaded: true,
                        projectDetails: result
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        projectDetails: {},
                        error
                    });
                }
            )
    }
    componentDidMount() {
        this.getProjectDetails();
    }
    render() {
        return (<React.Fragment>
            {(() => {
                if (this.state.uploadInProgress) {
                    <div className='sweet-loading'><ClipLoader
                        sizeUnit={"px"}
                        size={150}
                        color={'#123abc'}
                        loading={this.state.uploadInProgress}
                    />
                    </div>
                }
            })()}

            <div className="tab-pane fade active show" id="nav-projectdetails" role="tabpanel" aria-labelledby="nav-projectdetails-tab">
                <div className="d-flex flex-row row">
                    <div className="pr-details col-6">
                        <form>

                            <div className="form-group row">
                                <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                    data-placement="top" title="Project Name">Project
                            Name</label>
                                <div className="col-sm-8">
                                    <input type="text" className="form-control" id="colFormLabel" placeholder="" value={this.state.projectDetails.description} readOnly />
                                </div>
                            </div>
                            <div className="form-group row">
                                <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                    data-placement="top" title="Project ID">Project
                            ID</label>
                                <div className="col-sm-8">
                                    <input type="text" className="form-control" id="colFormLabel" placeholder="" value={this.state.projectDetails.project_number} readOnly />
                                </div>
                            </div>
                            <div className="form-group row">
                                <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                    data-placement="top" title="Project Type">Created
                            Date</label>
                                <div className="col-sm-8">
                                    <input type="text" className="form-control" id="colFormLabel" placeholder="" value={this.state.projectDetails.created_at} readOnly />
                                </div>
                            </div>
                            <div className="form-group row">
                                <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                    data-placement="top" title="Project Cost">Project
                            Cost</label>
                                <div className="col-sm-8">
                                    <input type="text" className="form-control" id="colFormLabel" placeholder="" />
                                </div>
                            </div>
                            <div className="form-group row">
                                <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                    data-placement="top" title="Project Value">Project
                            Value</label>
                                <div className="col-sm-8">
                                    <input type="number" className="form-control" id="colFormLabel" placeholder=" " />
                                </div>
                            </div>

                        </form>
                    </div>
                    <div class="col-6">
                        <div class="border flex-row">
                            <h3 class="d-block p-2 bg-grey ">Upload BOQs</h3>
                            <div class=" p-3 bg-white">
                                <div class="input-group mb-3">
                                    <div class="custom-file">
                                        <input ref={(ref) => { this.uploadInput = ref; }} onChange={this.onFileChange} type="file" class="custom-file-input" id="inputGroupFile02" />
                                        <label class="custom-file-label" for="inputGroupFile02" aria-describedby="inputGroupFileAddon02" style={{ color: this.state.fileName ? 'black' : '' }}> {this.state.fileName ? this.state.fileName : 'Choose File'}</label>
                                    </div>
                                </div>
                                <button class="btn btn-red mt-2" onClick={this.onUploadClick}>{this.state.uploadInProgress ? 'Uploading...' : 'Upload'}</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="mt-3">
                    <nav className="d-flex justify-content-between">
                        <div className="nav nav-tabs" id="nav-tab" role="tablist">
                            <a onClick={this.onBoqTabClick} className={"nav-item nav-link p-3 " + (this.state.selectedTab == 'boq' ? 'active' : '')} id="bottom-boqlist-tab" data-toggle="tab"
                                role="tab" aria-controls="nav-home" aria-selected="true">BOQ
                          List</a>
                            <a onClick={this.onPrTabClick} className={"nav-item nav-link p-3 " + (this.state.selectedTab == 'pr' ? 'active' : '')} id="bottom-purreq-tab" data-toggle="tab"
                                role="tab" aria-controls="nav-profile" aria-selected="false">Purchase Requisitions</a>


                        </div>
                        <form className="form-inline">
                            <div className="form-group">
                                <label for="inputPassword6">Filter by :</label>
                                <select className="form-control select2-combo" id="exampleFormControlSelect1">
                                    <option>Select</option>
                                    <option>Category A</option>
                                    <option>Category B</option>
                                </select>
                            </div>
                        </form>
                    </nav>
                    <div className="tab-content " id="nav-tabContent">
                        {(() => {
                            if (this.state.selectedTab == 'boq') {
                                return <div className="tab-pane fade show active" id="nav-boqlist-tab" role="tabpanel" aria-labelledby="bottom-boqlist-tab">
                                    <div className="d-flex flex-row table-list-darkheading ">
                                        <table className="table  table-striped table-bordered mb-0">
                                            <thead>
                                                <tr scope="col">
                                                    <th>BOQ Number</th>
                                                    <th>Project ID</th>
                                                    {/* <th>Project Name</th> */}
                                                    <th>Date Created</th>
                                                    <th>Date Approved</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {this.state.projectDetails.boq.map(item => {
                                                    if (item.entity_type_id == 'BOQ') {
                                                        return <tr scope="row" onClick={this.onBoqRowClick.bind(this, item)} key={item.boq_number}>
                                                            <td>{item.boq_number}</td>
                                                            <td>{item.project_id}</td>
                                                            {/* <td>{this.state.projectDetails.description}</td> */}
                                                            <td>{item.created_at}</td>
                                                            <td></td>
                                                            <td>{item.status}</td>
                                                        </tr>
                                                    }
                                                    return ''
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            } else if (this.state.selectedTab == 'pr') {
                                return <div className="tab-pane fade  show active" id="nav-purreq" role="tabpanel" aria-labelledby="nav-profile-tab">
                                    <div className="d-flex flex-row table-list-darkheading  ">

                                        <table className="table  table-striped table-bordered">
                                            <thead>
                                                <tr scope="col">
                                                    <th>PR Number</th>
                                                    <th>Project ID</th>
                                                    <th>Date Created</th>
                                                    <th>Date Approved</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {this.state.projectDetails.boq.map(item => {
                                                    if (item.entity_type_id == 'PR') {
                                                        return <tr scope="row" onClick={this.onPrRowClick.bind(this, item)} key={item.boq_number}>
                                                            <td>{item.boq_number}</td>
                                                            <td>{item.project_id}</td>
                                                            <td>{item.created_at}</td>
                                                            <td></td>
                                                            <td>{item.status}</td>
                                                        </tr>
                                                    }
                                                    return ''
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            }
                        })()}


                    </div>
                </div>
            </div>
        </React.Fragment>);
    }
}

export default Projectdetails; 
