import React, { Component } from "react";
import updatesprofileimg from "assets/images/media-img1.jpg";
import CardUpdates from "./card-updates";

class LatestUpdates extends Component {
  render() {
    return (
      <div className="shadow-box latest-updates-sec  mt-5 mb-5">
        <h3 className="bg-secondary p-3 text-white text-uppercase font-weight-light">
          Latest Updates
        </h3>
        <div className="d-flex flex-row p-2">
          <div className="p-2">
            <ul className="list-unstyled">
              <CardUpdates />
              <CardUpdates />
              <CardUpdates />
            </ul>
          </div>
          <div className="p-2">
            <ul className="list-unstyled">
              <CardUpdates />
              <CardUpdates />
              <CardUpdates />
            </ul>
          </div>
        </div>
        <a href="#" className="d-block text-right p-2 view-more-link ">
          <u>View more</u>
        </a>
      </div>
    );
  }
}

export default LatestUpdates;
