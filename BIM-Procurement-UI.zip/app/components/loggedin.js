import React, { Component } from "react";
import userimage from "assets/images/user.png";

class LoggedIn extends Component {
  render() {
    return (
      <ul className="d-inline-flex ">
        <li className="notify d-flex  align-items-center">
          <a href="#">
            <sup className="badge-sup">1</sup>
            <i className="far fa-bell" />
          </a>
        </li>
        <li className="mail d-flex  align-items-center">
          <a href="#">
            <i className="far fa-question-circle" />
          </a>
        </li>
        <li className="signed-in d-flex  align-items-center">
          hello, Chris Hardy!
          <a href="#">
            <img className="user-img rounded-circle m-2" src={userimage} />
          </a>
        </li>
      </ul>
    );
  }
}

export default LoggedIn;
