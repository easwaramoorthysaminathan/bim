import React, { Component } from "react";

class SearchPanel extends Component {
  render() {
    return (
      <div className="search-products pt-3 pr-3 pl-3 pb-0 d-flex justify-content-end">
        <form className="form-inline">
          <div className="form-group">
            <input
              type="text"
              id="inputPassword6"
              className="form-control mr-1 bim-search-field"
              aria-describedby="passwordHelpInline"
              size="30"
              placeholder="Search by Projects, BOQs, PRs, POs"
            />
            <button className="btn btn-primary bim-btn-search">Search</button>
          </div>
        </form>
      </div>
    );
  }
}

export default SearchPanel;
