import React from "react";
import Podetails from "./podetails"
import Polist from "./polist"

class Boqtabs extends React.Component {
    constructor(props) {
        console.log("BOQTAbs");
        console.log(props);
        super(props);
        this.state = {
            selectedPoForEdit: null,
            props: props
        };
        this.onPoListMenuClick = this.onPoListMenuClick.bind(this);
        this.onPoRowClick = this.onPoRowClick.bind(this);
    }
    onPoListMenuClick() {
        this.setState({
            selectedPoForEdit: null, selectedPrForEdit: null
        });
    }

    onPoRowClick(pRow) {
        this.setState({
            selectedPoForEdit: pRow.poNumber
        });
    }
    
    render() {
        return (<React.Fragment>
            <nav>
                <div className="nav nav-tabs" id="nav-tab" role="tablist">
                    <a className={"nav-item nav-link  p-3 " + (this.state.selectedPoForEdit == null && this.state.selectedPrForEdit == null ? 'active' : '')} id="nav-projectlist-tab" data-toggle="tab" href="#nav-projectlist"
                        role="tab" aria-controls="nav-home" aria-selected="true" onClick={this.onPoListMenuClick}>Purchase Orders
                    </a>
                    {this.state.selectedPoForEdit != null ? (
                        <a className="nav-item nav-link  p-3 active" id="nav-boq-tab" data-toggle="tab" href="#nav-boq" role="tab"
                            aria-controls="nav-boq" aria-selected="true" style={{ display: 'block' }}>{this.state.selectedPoForEdit}
                        </a>) : ('')}
                </div>
            </nav>
            <div className="tab-content p-3" id="nav-tabContent">
                {(() => {
                    if (this.state.selectedPoForEdit != null) {
                        return (
                            <Podetails selectedPoForEdit={this.state.selectedPoForEdit} />
                        )
                    } else {
                        return (
                            <Polist onPoRowClick={this.onPoRowClick}/>
                        )
                    }
                })()}
            </div></React.Fragment>);
    }
}

export default Boqtabs;