import React from "react";
import { BASE_API_URL, BASE_API_URL2 } from "../utils/constants";

class GrCreate extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedBOQ: null,
      selectedPR: null,
      props: props,
      grDetails: {},
      poNumber: '',
      poList: []
    };
    this.onSaveClick = this.onSaveClick.bind(this);
    this.onCancelClick = this.onCancelClick.bind(this);
    this.onPochange = this.onPochange.bind(this);
    this.onSupplierChange = this.onSupplierChange.bind(this);
    this.onDateChange = this.onDateChange.bind(this);
    this.SiteChange = this.SiteChange.bind(this);
    this.onViewPOClick = this.onViewPOClick.bind(this);
    this.onPoViewClick = this.onPoViewClick.bind(this);
    this.onSearchPOClick = this.onSearchPOClick.bind(this);
  }
  onPoViewClick() {
    this.state.props.onPoViewClick(this.state.poNumber);
  }
  onSearchPOClick() {
    fetch(BASE_API_URL + "/purchase_order?filter=poNumber,eq," + this.state.poNumber + "&join=po_items")
      .then(res => res.json())
      .then(
        (result) => {
          var po = result.records[0];
          this.setState({
            supplier: po.supplier,
            grDetails: { gr_items: po.po_items }
          });
        })
  }
  onPochange(event) {
    this.setState({ poNumber: event.target.value });
  }
  onSupplierChange(event) {
    this.setState({ supplier: event.target.value });
  }
  onDateChange(event) {
    this.setState({ date_received: event.target.value });
  }
  SiteChange(event) {
    this.setState({ sitename: event.target.value });
  }
  onSaveClick() {
    const data = new FormData();
    data.append('po', this.state.poNumber);
    data.append('site_name', this.state.sitename);
    data.append('date_received', this.state.date_received);
    fetch(BASE_API_URL2 + "/goods_receipt.php", { method: 'POST', body: data });
  }
  onViewPOClick() { }
  onCancelClick() { }
  componentDidMount() {
    fetch(BASE_API_URL + "/purchase_order")
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            isLoaded: true,
            poList: result.records
          });
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          this.setState({
            isLoaded: true,
            grDetails: {},
            error
          });
        }
      )
  }
  render() {
    return (<React.Fragment>
      {(() => {
        if (this.state.grDetails) {
          return <div class="tab-pane fade show active" id="nav-editpo" role="tabpanel" aria-labelledby="nav-editpo-tab">
            <div class="row mr-0 ml-0 bg-grey-light p-3 border">
              <div class="po-details   col-sm-12 col-md-6 pt-3">
                <form>
                  <div class="form-group row">
                    <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                      data-placement="top" title="" data-original-title="PO Number">PO Number</label>
                    <div class="col-sm-8">
                      <input type="text" class="form-control" id="colFormLabel" placeholder="" onChange={this.onPochange} value={this.state.poNumber} />
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                      data-placement="top" title="" data-original-title="Supplier Name">Supplier Name</label>
                    <div class="col-sm-8">
                      <input type="text" class="form-control" id="colFormLabel" placeholder="" onChange={this.onSupplierChange} value={this.state.supplier} />
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                      data-placement="top" title="" data-original-title="Date Received">Date Received</label>
                    <div class="col-sm-8">
                      <input type="date" class="form-control" id="colFormLabel" placeholder="" onChange={this.onDateChange} value={this.state.date_received} />
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                      data-placement="top" title="" data-original-title="Site Name">Site Name</label>
                    <div class="col-sm-8">
                      <input type="text" class="form-control" id="colFormLabel" placeholder="" onChange={this.SiteChange} value={this.state.sitename} />
                    </div>
                  </div>
                </form>



                <div class="pt-3 d-flex justify-content-end"><button class="btn btn-red pr-5 pl-5 mr-1" onClick={this.onSaveClick.bind(this)}>Save</button>
                  <button class=" btn btn-primary pr-5 pl-5">Cancel</button></div>
              </div>
              <div class="col-sm-12 col-md-6 pt-3">
                <button class="btn btn-outline-light  pl-5 pr-5" onClick={this.onSearchPOClick}>Search</button><button onClick={this.onPoViewClick} class="btn btn-outline-light  pl-5 pr-5 ml-3">View PO</button>
              </div>
            </div>
            <div class=" table-list-darkheading mt-1 ">
              <div class="add-del-panel  d-flex flex-row pt-5 pb-1 justify-content-between">
                <div class="button-holder">

                </div>

                <table class="table  table-striped table-bordered">
                  <thead>
                    <tr scope="col">
                      <th>Item Number</th>
                      <th>Item Description</th>
                      <th>Qty Ordered</th>
                      <th>Qty Shipped</th>
                      <th>Qty Accepted</th>
                      <th>Qty Rejected</th>
                      <th>Batch Number</th>
                      <th>Comments</th>


                    </tr>
                  </thead>
                  <tbody>
                    {(this.state.grDetails.gr_items || []).map(item => {
                      return <tr scope="row">
                        <td>{item.part_number ? item.part_number : ''}</td>
                        <td>{item.sku_name}</td>
                        <td>{item.quantity}</td>
                        <td><input type="text" value={item.received_quantity} /></td>
                        <td><input type="text" value={item.accepted_quantity} /></td>
                        <td><input type="text" value={item.rejected_quantity} /></td>
                        <td>{item.batch}</td>
                        <td>{item.comment}</td>
                      </tr>
                    })}
                  </tbody>
                </table>



              </div>
              <div class="d-flex flex-column remarks-col mt-3">
                <label><b>Remarks</b></label>
                <textarea rows="8" cols="50"> Enter any remarks</textarea>
              </div>
            </div>
          </div>
        }
      })()}
    </React.Fragment>);
  }
}

export default GrCreate;