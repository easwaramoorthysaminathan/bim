import React from "react";
import Boqdetails from "./boqdetails"
import Prdetails from "./prdetails"
import Boqlist from "./boqlist"

class Boqtabs extends React.Component {
    constructor(props) {
        console.log("BOQTAbs");
        console.log(props);
        super(props);
        this.state = {
            selectedBOQForEdit: null,
            selectedPrForEdit: null,
            props: props
        };
        this.onBoqListMenuClick = this.onBoqListMenuClick.bind(this);
        this.onBoqRowClick = this.onBoqRowClick.bind(this);
        this.onPrRowClick = this.onPrRowClick.bind(this);
    }
    onBoqListMenuClick() {
        this.setState({
            selectedBOQForEdit: null, selectedPrForEdit: null
        });
    }

    onBoqRowClick(pRow) {
        this.setState({
            selectedBOQForEdit: pRow.boq_number
        });
    }
    onPrRowClick(pRow) {
        console.log(pRow);
        this.setState({
            selectedPrForEdit: pRow != 'Create PR' ? pRow.boq_number : 'Create PR'
        });
    }
    render() {
        return (<React.Fragment>
            <nav>
                <div className="nav nav-tabs" id="nav-tab" role="tablist">
                    <a className={"nav-item nav-link  p-3 " + (this.state.selectedBOQForEdit == null && this.state.selectedPrForEdit == null ? 'active' : '')} id="nav-projectlist-tab" data-toggle="tab" href="#nav-projectlist"
                        role="tab" aria-controls="nav-home" aria-selected="true" onClick={this.onBoqListMenuClick}>{this.state.props.location.pathname == '/boqs' ? 'BOQs' : 'Purchase Requisitions'}
                    </a>
                    {this.state.selectedBOQForEdit != null ? (
                        <a className="nav-item nav-link  p-3 active" id="nav-boq-tab" data-toggle="tab" href="#nav-boq" role="tab"
                            aria-controls="nav-boq" aria-selected="true" style={{ display: 'block' }}>{this.state.selectedBOQForEdit}
                        </a>) : ('')}

                    {this.state.selectedPrForEdit != null ? (
                        <a className="nav-item nav-link  p-3 active" id="nav-boq-tab" data-toggle="tab" href="#nav-boq" role="tab"
                            aria-controls="nav-boq" aria-selected="true" style={{ display: 'block' }}>{this.state.selectedPrForEdit}
                        </a>) : ('')}

                </div>
            </nav>
            <div className="tab-content p-3" id="nav-tabContent">
                {(() => {
                    if (this.state.selectedBOQForEdit != null) {
                        return (
                            <Boqdetails selectedBOQForEdit={this.state.selectedBOQForEdit} />
                        )
                    } else if (this.state.selectedPrForEdit != null) {
                        return (
                            <Prdetails selectedBOQForEdit={this.state.selectedPrForEdit} />
                        )
                    } else {
                        return (
                            <Boqlist entity={this.state.props.location.pathname == '/boqs' ? 'BOQ' : 'PR'} onBoqRowClick={this.onBoqRowClick} onPrRowClick={this.onPrRowClick} />
                        )
                    }
                })()}
            </div></React.Fragment>);
    }
}

export default Boqtabs;