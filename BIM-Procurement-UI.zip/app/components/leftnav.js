import React, { Component } from "react";

class LeftNav extends Component {
  render() {
    return (
      <aside class="left-navpanel">
        <div class="pad">
          <div class="accordion" id="accordionExample">
            <div class="card">
              <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                  <a
                    class="btn btn-link btn-block selected"
                    href="home"
                  >
                    <i class="icon-Dashboard" />
                    Dashboard
                  </a>
                </h5>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingTwo">
                <h5 class="mb-0">
                  <a href="projects" class="btn btn-link btn-block collapsed">
                    <i class="icon-purchasing" />
                    Purchasing
                  </a>
                </h5>
              </div>
              <div
                id="collapseTwo"
                class="collapse show"
                aria-labelledby="headingTwo"
                data-parent="#accordionExample"
              >
                <div class="card-body">
                  <ul>
                    <li>
                      <a href="projects">
                        <i class="icon-Projects" />
                        Projects
                      </a>
                    </li>
                    <li>
                      <a href="boqs">
                        <i class="icon-BOQ" />
                        BOQs
                      </a>
                    </li>
                    <li>
                      <a href="prs">
                        <i class="icon-Purchase-Requisitioner" />
                        Purchase Requisitions
                      </a>
                    </li>
                    <li>
                      <a href="pos">
                        <i class="icon-purchase_order" />
                        Purchase Orders
                      </a>
                    </li>
                    <li>
                      <a href="grs">
                        <i class="icon-goods_receipts" />
                        Goods Receipt
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingThreeSkip">
                <h5 class="mb-0">
                  <a
                    href="supplier_management.html"
                    class="btn btn-link btn-block collapsed"
                  >
                    <i class="icon-Supplier-Mangement" />
                    Supplier Management
                  </a>
                </h5>
              </div>
              <div
                id="collapseTwo"
                class="collapse show"
                aria-labelledby="headingTwo"
                data-parent="#accordionExample"
              >
                <div class="card-body">
                  <ul>
                    <li>
                      <a href="qualified_suppliers.html">
                        <i class="icon-Qualified-Supplier" />
                        Qualified Suppliers
                      </a>
                    </li>
                    <li>
                      <a href="non_qualified_suppliers.html.html">
                        <i class="icon-Non-Qualified-Supplier" />
                        Non-Qualified Suppliers
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingThreeSkip">
                <h5 class="mb-0">
                  <a
                    href="contract_management.html"
                    class="btn btn-link btn-block collapsed"
                  >
                    <i class="icon-Contract-Management" />
                    Contract Management
                  </a>
                </h5>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingFive">
                <h5 class="mb-0">
                  <a
                    href="reporting.html"
                    class="btn btn-link btn-block collapsed"
                  >
                    <i class="icon-Reporting" />
                    Reporting
                  </a>
                </h5>
              </div>
            </div>
          </div>
        </div>
      </aside>
    );
  }
}

export default LeftNav;
