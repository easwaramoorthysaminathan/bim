import React, { Component } from "react";

import CardDashboard from "./card-dashboard";
import LatestUpdates from "./latest-updates";

class DashboardPanel extends Component {
  render() {
    return (
      <React.Fragment>
        <div className="mt-5">
          <CardDashboard />
          <LatestUpdates />
        </div>
      </React.Fragment>
    );
  }
}

export default DashboardPanel;
