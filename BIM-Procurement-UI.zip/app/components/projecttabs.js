import React from "react";
import Projectlist from "./projectlist"
import Projectdetails from "./projectdetails"
import Boqdetails from "./boqdetails"
import Prdetails from "./prdetails"

class Projecttabs extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedProjectForEdit: null,
            selectedBOQForEdit: null,
            selectedProjectName: null,
            props: props
        };
        this.onProjectRowClick = this.onProjectRowClick.bind(this);
        this.onProjectListMenuClick = this.onProjectListMenuClick.bind(this);
        this.onProjectDetailMenuClick = this.onProjectDetailMenuClick.bind(this);
        this.onBoqRowClick = this.onBoqRowClick.bind(this);
        this.onPrRowClick = this.onPrRowClick.bind(this);
    }
    onProjectListMenuClick() {
        this.setState({
            selectedProjectForEdit: null,
            selectedBOQForEdit: null
        });
    }
    onProjectDetailMenuClick() {
        this.setState({
            selectedBOQForEdit: null,
            selectedPrForEdit: null
        });
    }
    onProjectRowClick(pRow) {
        // console.log(pRow);
        this.setState({
            selectedProjectForEdit: pRow.project_number,
            selectedProjectName: pRow.description,
            selectedBOQForEdit: null,
            selectedPrForEdit: null
        });
    }

    onBoqRowClick(pRow) {
        this.setState({
            selectedPrForEdit: null,
            selectedBOQForEdit: pRow.boq_number
        });
    }
    onPrRowClick(pRow) {
        this.setState({
            selectedBOQForEdit: null,
            selectedPrForEdit: pRow.boq_number
        });
    }
    render() {
        return (<React.Fragment>
            <nav>
                <div className="nav nav-tabs" id="nav-tab" role="tablist">
                    <a className={"nav-item nav-link  p-3 " + (this.state.selectedProjectForEdit == null ? 'active' : '')} id="nav-projectlist-tab" data-toggle="tab" href="#nav-projectlist"
                        role="tab" aria-controls="nav-home" aria-selected="true" onClick={this.onProjectListMenuClick}>Project List
                  </a>
                    {this.state.selectedProjectForEdit != null ? (
                        <a className={"nav-item nav-link p-3 " + (this.state.selectedBOQForEdit == null && this.state.selectedPrForEdit == null ? 'active' : '')} id="nav-projectdetails-tab" data-toggle="tab" href="#nav-projectdetails"
                            role="tab" aria-controls="nav-profile" aria-selected="true" onClick={this.onProjectDetailMenuClick}>{this.state.selectedProjectName}
                        </a>) : ('')}
                    {this.state.selectedBOQForEdit != null || this.state.selectedPrForEdit != null ? (
                        <a className="nav-item nav-link  p-3 active" id="nav-boq-tab" data-toggle="tab" href="#nav-boq" role="tab"
                            aria-controls="nav-boq" aria-selected="true" style={{ display: 'block' }}>{this.state.selectedBOQForEdit || this.state.selectedPrForEdit}
                        </a>) : ('')}

                </div>
            </nav>
            <div className="tab-content p-3" id="nav-tabContent">
                {(() => {
                    if (this.state.selectedBOQForEdit != null) {
                        return (
                            <Boqdetails selectedBOQForEdit={this.state.selectedBOQForEdit} />
                        )
                    } else if (this.state.selectedPrForEdit != null) {
                        return (
                            <Prdetails selectedBOQForEdit={this.state.selectedPrForEdit} />
                        )
                    } else if (this.state.selectedProjectForEdit != null) {
                        return (
                            <Projectdetails selectedProjectForEdit={this.state.selectedProjectForEdit} onBoqRowClick={this.onBoqRowClick} onPrRowClick={this.onPrRowClick} />
                        )
                    } else {
                        return (
                            <Projectlist onProjectRowClick={this.onProjectRowClick} />
                        )
                    }
                })()}
            </div></React.Fragment>);
    }
}

export default Projecttabs;