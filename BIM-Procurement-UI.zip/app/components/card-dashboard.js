import React, { Component } from "react";

class CardDashboard extends Component {
  render() {
    return (
      <div class="shadow-box card-dashboard pl-5  pr-5 bg-white ">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-6 pb-4 pt-5">
            <div class="card red">
              <div class="card-body d-flex">
                <a
                  href="purchase_requisitions.html"
                  class="d-flex justify-content-between "
                >
                  <i class="icon-Pending align-self-center red" />
                  <span class="text-uppercase align-self-center">
                    <mark>25</mark>
                    <br />
                    Purchase Requisitions
                    <br />
                    Created this month
                  </span>
                </a>
              </div>
            </div>
          </div>
          <div class="col-sm-12 col-md-12 col-lg-6 pb-4 pt-5">
            <div class="card grey">
              <div class="card-body d-flex">
                <a
                  href="pending-actions.html"
                  class="d-flex justify-content-between "
                >
                  <i class="icon-Incomplete align-self-center grey" />
                  <span class="text-uppercase align-self-center">
                    <mark>15</mark>
                    <br />
                    Purchase Requisitions
                    <br />
                    Pending Approval
                  </span>
                </a>
              </div>
            </div>
          </div>
          <div class="col-sm-12 col-md-12 col-lg-6 pb-5 pt-4">
            <div class="card grey">
              <div class="card-body d-flex">
                <a
                  href="purchase_orders.html"
                  class="d-flex justify-content-between "
                >
                  <i class="icon-pending_order align-self-center grey" />
                  <span class="text-uppercase align-self-center">
                    <mark>07</mark>
                    <br />
                    Purchase Orders <br />
                    Pending Acceptance
                  </span>
                </a>
              </div>
            </div>
          </div>
          <div class="col-sm-12 col-md-12 col-lg-6 pb-5 pt-4">
            <div class="card red">
              <div class="card-body d-flex">
                <a
                  href="pending-actions.html"
                  class="d-flex justify-content-between "
                >
                  <i class="icon-Reject-POs align-self-center red" />
                  <span class="text-uppercase align-self-center">
                    <mark>05</mark>
                    <br />
                    Rejected
                    <br />
                    POs to attend
                  </span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default CardDashboard;
