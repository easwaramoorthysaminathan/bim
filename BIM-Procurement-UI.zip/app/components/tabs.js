import React from "react";

class Tabs extends React.Component {

    render() {
        return (<React.Fragment>
            <nav>
                <div className="nav nav-tabs" id="nav-tab" role="tablist">
                    <a className="nav-item nav-link  p-3 " id="nav-projectlist-tab" data-toggle="tab" href="#nav-projectlist"
                        role="tab" aria-controls="nav-home" aria-selected="true">Project List
                  </a>
                    <a className="nav-item nav-link p-3 active" id="nav-projectdetails-tab" data-toggle="tab" href="#nav-projectdetails"
                        role="tab" aria-controls="nav-profile" aria-selected="true">Project - Thai Hospital
                    </a>
                    <a className="nav-item nav-link  p-3 " id="nav-boq-tab" data-toggle="tab" href="#nav-boq" role="tab"
                        aria-controls="nav-boq" aria-selected="false">BOQs List
                  </a>

                </div>
            </nav>
            <div className="tab-content p-3" id="nav-tabContent">
                <div className="tab-pane fade " id="nav-projectlist" role="tabpanel" aria-labelledby="nav-projectlist-tab">
                    <div className="show-by-category justify-content-end d-flex">
                        <form className="form-inline">
                            <div className="form-group">
                                <label for="inputPassword6">Filter by :</label>
                                <select className="form-control select2-combo" id="exampleFormControlSelect1">
                                    <option>Select</option>
                                    <option>All Categories</option>
                                    <option>All Categories</option>
                                    <option>All Categories</option>
                                    <option>All Categories</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div className="d-flex flex-row table-list-darkheading mt-3">

                        <table className="table  table-striped table-bordered">
                            <thead>
                                <tr scope="col">
                                    <th>Project Number</th>
                                    <th>Project Name</th>
                                    <th>Project Type</th>
                                    <th>Date Created</th>
                                    <th>Date Approved</th>
                                    <th>Status</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr scope="row">
                                    <td onclick="window.location='project-details.html'">PR
                            120500</td>
                                    <td onclick="window.location='project-details.html'">Thai Hospital</td>
                                    <td onclick="window.location='project-details.html'"></td>
                                    <td onclick="window.location='project-details.html'">2018-09-28</td>
                                    <td onclick="window.location='project-details.html'">2018-09-30</td>
                                    <td onclick="window.location='project-details.html'"></td>

                                </tr>
                                <tr scope="row">
                                    <td onclick="window.location='project-details.html'">PR 120500</td>
                                    <td onclick="window.location='project-details.html'">Thai Hospital</td>
                                    <td onclick="window.location='project-details.html'"></td>
                                    <td onclick="window.location='project-details.html'">2018-09-28</td>
                                    <td onclick="window.location='project-details.html'">2018-09-30</td>
                                    <td onclick="window.location='project-details.html'"></td>

                                </tr>
                                <tr scope="row">
                                    <td onclick="window.location='project-details.html'">PR 120500</td>
                                    <td onclick="window.location='project-details.html'">Thai Hospital</td>
                                    <td onclick="window.location='project-details.html'"></td>
                                    <td onclick="window.location='project-details.html'">2018-09-28</td>
                                    <td onclick="window.location='project-details.html'">2018-09-30</td>
                                    <td onclick="window.location='project-details.html'"></td>

                                </tr>
                            </tbody>
                        </table>



                    </div>
                </div>
                <div className="tab-pane fade active show" id="nav-projectdetails" role="tabpanel" aria-labelledby="nav-projectdetails-tab">
                    <div className="d-flex flex-row row">
                        <div className="pr-details col-6">
                            <form>

                                <div className="form-group row">
                                    <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                        data-placement="top" title="Project Name">Project
                            Name</label>
                                    <div className="col-sm-8">
                                        <input type="number" className="form-control" id="colFormLabel" placeholder="Thai Hospital" />
                                    </div>
                                </div>
                                <div className="form-group row">
                                    <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                        data-placement="top" title="Project ID">Project
                            ID</label>
                                    <div className="col-sm-8">
                                        <input type="text" className="form-control" id="colFormLabel" placeholder="PR 120500" />
                                    </div>
                                </div>
                                <div className="form-group row">
                                    <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                        data-placement="top" title="Project Type">Created
                            Date</label>
                                    <div className="col-sm-8">
                                        <input type="text" className="form-control" id="colFormLabel" placeholder="2018-09-28" />
                                    </div>
                                </div>
                                <div className="form-group row">
                                    <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                        data-placement="top" title="Project Cost">Project
                            Cost</label>
                                    <div className="col-sm-8">
                                        <input type="text" className="form-control" id="colFormLabel" placeholder="" />
                                    </div>
                                </div>
                                <div className="form-group row">
                                    <label for="colFormLabel" className="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                        data-placement="top" title="Project Value">Project
                            Value</label>
                                    <div className="col-sm-8">
                                        <input type="number" className="form-control" id="colFormLabel" placeholder=" " />
                                    </div>
                                </div>

                            </form>
                        </div>

                    </div>
                    <div className="mt-3">
                        <nav className="d-flex justify-content-between">
                            <div className="nav nav-tabs" id="nav-tab" role="tablist">
                                <a className="nav-item nav-link active p-3" id="bottom-boqlist-tab" data-toggle="tab" href="#nav-boqlist-tab"
                                    role="tab" aria-controls="nav-home" aria-selected="true">BOQ
                          List</a>
                                <a className="nav-item nav-link p-3" id="bottom-purreq-tab" data-toggle="tab" href="#nav-purreq"
                                    role="tab" aria-controls="nav-profile" aria-selected="false">Purchase Requisitions</a>


                            </div>
                            <form className="form-inline">
                                <div className="form-group">
                                    <label for="inputPassword6">Filter by :</label>
                                    <select className="form-control select2-combo" id="exampleFormControlSelect1">
                                        <option>Select</option>
                                        <option>All Categories</option>
                                        <option>All Categories</option>
                                        <option>All Categories</option>
                                        <option>All Categories</option>
                                    </select>
                                </div>
                            </form>
                        </nav>
                        <div className="tab-content " id="nav-tabContent">
                            <div className="tab-pane fade show active" id="nav-boqlist-tab" role="tabpanel" aria-labelledby="bottom-boqlist-tab">



                                <div className="d-flex flex-row table-list-darkheading ">

                                    <table className="table  table-striped table-bordered mb-0">
                                        <thead>
                                            <tr scope="col">
                                                <th>BOQ Number</th>
                                                <th>Project ID</th>
                                                <th>Project Name</th>
                                                <th>Date Created</th>
                                                <th>Date Approved</th>
                                                <th>Status</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr scope="row">
                                                <td onclick="window.location='boqs-details.html'">BOQs 123</td>
                                                <td onclick="window.location='boqs-details.html'">456789</td>
                                                <td onclick="window.location='boqs-details.html'"></td>
                                                <td onclick="window.location='boqs-details.html'">2018-09-28</td>
                                                <td onclick="window.location='boqs-details.html'">2018-09-30</td>
                                                <td onclick="window.location='boqs-details.html'"></td>

                                            </tr>
                                            <tr scope="row">
                                                <td onclick="window.location='boqs-details.html'">BOQs 123</td>
                                                <td onclick="window.location='boqs-details.html'">456789</td>
                                                <td onclick="window.location='boqs-details.html'"></td>
                                                <td onclick="window.location='boqs-details.html'">2018-09-28</td>
                                                <td onclick="window.location='boqs-details.html'">2018-09-30</td>
                                                <td onclick="window.location='boqs-details.html'"></td>

                                            </tr>
                                            <tr scope="row">
                                                <td onclick="window.location='boqs-details.html'">BOQs 123</td>
                                                <td onclick="window.location='boqs-details.html'">456789</td>
                                                <td onclick="window.location='boqs-details.html'"></td>
                                                <td onclick="window.location='boqs-details.html'">2018-09-28</td>
                                                <td onclick="window.location='boqs-details.html'"></td>
                                                <td onclick="window.location='boqs-details.html'"></td>

                                            </tr>
                                        </tbody>
                                    </table>



                                </div>
                            </div>
                            <div className="tab-pane fade" id="nav-purreq" role="tabpanel" aria-labelledby="nav-profile-tab">
                                <div className="d-flex flex-row table-list-darkheading  ">

                                    <table className="table  table-striped table-bordered">
                                        <thead>
                                            <tr scope="col">
                                                <th>PR Number</th>
                                                <th>Project ID</th>
                                                <th>Date Created</th>
                                                <th>Date Approved</th>
                                                <th>Status</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr scope="row">
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>

                                            </tr>
                                            <tr scope="row">
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>

                                            </tr>
                                            <tr scope="row">
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>

                                            </tr>
                                        </tbody>
                                    </table>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="tab-pane fade " id="nav-boq" role="tabpanel" aria-labelledby="nav-boq-tab">
                    <div className="show-by-category justify-content-end d-flex">
                        <form className="form-inline">
                            <div className="form-group">
                                <label for="inputPassword6">Filter by :</label>
                                <select className="form-control select2-combo" id="exampleFormControlSelect1">
                                    <option>Select</option>
                                    <option>All Categories</option>
                                    <option>All Categories</option>
                                    <option>All Categories</option>
                                    <option>All Categories</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div className="d-flex flex-row table-list-darkheading mt-3">

                        <table className="table  table-striped table-bordered">
                            <thead>
                                <tr scope="col">
                                    <th>BOQ Number</th>
                                    <th>Project ID</th>
                                    <th>Project Name</th>
                                    <th>Date Created</th>
                                    <th>Date Approved</th>
                                    <th>Status</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr scope="row">
                                    <td>BOQs 123</td>
                                    <td>456789</td>
                                    <td></td>
                                    <td>2018-09-28</td>
                                    <td>2018-09-30</td>
                                    <td></td>

                                </tr>
                                <tr scope="row">
                                    <td>BOQs 123</td>
                                    <td>456789</td>
                                    <td></td>
                                    <td>2018-09-28</td>
                                    <td>2018-09-30</td>
                                    <td></td>
                                </tr>
                                <tr scope="row">
                                    <td>BOQs 123</td>
                                    <td>456789</td>
                                    <td></td>
                                    <td>2018-09-28</td>
                                    <td>2018-09-30</td>
                                    <td></td>

                                </tr>
                            </tbody>
                        </table>



                    </div>
                </div>

            </div>
        </React.Fragment>);
    }
}

export default Tabs;