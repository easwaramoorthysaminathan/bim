import React from "react";
import { BASE_API_URL } from "../utils/constants";

class Polist extends React.Component {
    //items:Array
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            props: props,
            items: []
        };
        this.onPoRowClick = this.onPoRowClick.bind(this);
    }
    componentDidMount() {
        console.log(this.state);
        fetch(BASE_API_URL + "/purchase_order?join=project&join=boq_items")
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        isLoaded: true,
                        items: result.records
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        items: [],
                        error
                    });
                }
            )
    }
    onPoRowClick(item) {
        this.state.props.onPoRowClick(item);
    }
    onPrRowClick(item) {
        this.state.props.onPrRowClick(item);
    }
    render() {
        return (<React.Fragment>
            <div className="tab-pane fade  active show" id="nav-projectlist" role="tabpanel" aria-labelledby="nav-projectlist-tab">
                <div className="show-by-category justify-content-end d-flex">
                    <form className="form-inline">
                        <div className="form-group">
                            <label for="inputPassword6">Filter by :</label>
                            <select className="form-control select2-combo" id="exampleFormControlSelect1">
                                <option>Select</option>
                                <option>Category A</option>
                                <option>Category B</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div className="d-flex flex-row table-list-darkheading mt-3">
                    {(() => {
                        
                            return <table class="table  table-striped table-bordered mb-0">
                                <thead>
                                    <tr scope="col">
										<th>BOQ</th>
                                        <th>PO Number</th>
                                        <th>Supplier Name</th>
                                        <th>PO Date</th>
                                        <th>Total PO Amount (Baht)</th>
                                        <th>PO Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.items.map(item => (
                                        <tr scope="row" key={item.poNumber} onClick={this.onPoRowClick.bind(this, item)}>
											<td>{item.boq_id}</td>
                                            <td>{item.poNumber}</td>
                                            <td>{item.supplier}</td>
                                            <td>{item.po_date}</td>
                                            <td>{Math.round(item.total_price)}</td>
                                            <td>{item.status}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                    })()}
                </div>

            </div>
        </React.Fragment>);
    }
}

export default Polist;
