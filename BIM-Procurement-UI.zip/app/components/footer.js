import React from 'react';
class Footer extends React.Component {
    constructor(props) {
        super(props);
        //this.moveToTop = this.moveToTop.bind(this);
        
    }
    componentDidMount() {
        console.log('-----footer mouted------');
    }
    componentDidUpdate() {
        //console.log('-----footer updated------');
    }  
    moveToTop(){
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
    render(){
        //console.log('-----footer------');
        return(
            <React.Fragment>
                <footer className="footer">
                    footer
                </footer>
            </React.Fragment>
        );
    }    
}

  export default Footer;