import React from "react";
import { BASE_API_URL } from "../utils/constants";

class Podetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedBOQ: null,
            selectedPR: null,
            props: props,
            poDetails: {}
        };
        this.onApproveClick = this.onApproveClick.bind(this);
        this.onMapItemsClick = this.onMapItemsClick.bind(this);
    }
    onApproveClick() { }
    onMapItemsClick() { }
    componentDidMount() {
        fetch(BASE_API_URL + "/purchase_order/" + this.props.selectedPoForEdit + "?join=po_items&join=boq,customer")
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        isLoaded: true,
                        poDetails: result
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        poDetails: {},
                        error
                    });
                }
            )
    }
    render() {
        return (<React.Fragment>
            {(() => {
                if (this.state.poDetails && this.state.poDetails.boq_id) {
                    return <div class="tab-pane fade show active" id="nav-editpo" role="tabpanel" aria-labelledby="nav-editpo-tab">
                        <div class="row mr-0 ml-0 ">
                            <div class="po-details merged-txtfields  col-sm-12 col-md-6 pt-3">
                                <form>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="PO Date">PO Status</label>
                                        <div class="col-sm-8 d-flex">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="Pending Approval" readOnly value={'Pending Approval'} />
                                            <a href="#" class="btn btn-link bim-btn-link">Actions Log</a>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="PO Date">PO Number</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.props.selectedPoForEdit} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="PO Date">PO Date</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.po_date} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Supplier Name">Supplier Name</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.supplier} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Address">Address</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.customer_id.address} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Phone">Phone</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.customer_id.phone} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Email">Email</label>
                                        <div class="col-sm-8">
                                            <input type="email" class="form-control border-bottom" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.customer_id.email} />
                                        </div>
                                    </div>


                                </form>
                                <div class="mt-5 pt-4 row"><label><b>Payment Terms</b><br />
                                    Within 30days after received the invoice.</label></div>
                            </div>
                            <div class=" col-sm-12 col-md-6 pt-3">
                                <div class=" row flex-column pb-3  status-container ext-head-tab table-list-lightheading mappped-status  ">
                                    <div class="p-3 ext-head bg-red border-bottom"><b>PO Status: Pending Approval</b></div>
                                    <div class="p-3 ext-head">
                                        <form>
                                            <div class="form-group d-flex mb-0">
                                                <label for="inputEmail3" class="col-form-label"><b>Approver Level :</b></label>
                                                <div class="">
                                                    <select class="form-control select2-combo" id="exampleFormControlSelect1">
                                                        <option>Purchase Manager</option>
                                                        <option>All Categories</option>
                                                        <option>All Categories</option>
                                                        <option>All Categories</option>
                                                        <option>All Categories</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <table class="table table-bordered table-striped ">

                                        <thead>
                                            <tr>
                                                <th scope="col">User</th>
                                                <th scope="col">Role</th>
                                                <th scope="col">Date of Action</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td scope="row"> John A</td>
                                                <td>Manager</td>
                                                <td></td>
                                                <td>
                                                    <button class="btn btn-success btn-sm-width btn-approve">Approve</button>
                                                    <button class="btn btn-danger btn-sm-width">Reject</button>

                                                </td>
                                            </tr>


                                        </tbody>
                                    </table>

                                </div>
                                <div class="po-details merged-txtfields ">
                                    <div class="row mb-2"><a class="btn btn-primary bim-btn-search" id="updatenewpo" data-toggle="tab" href="#nav-newpo">Update as a
                            new PO</a></div>
                                    <label class="row"><b>Bill to</b></label>

                                    <form>

                                        <div class="form-group row">
                                            <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                                data-placement="top" title="" data-original-title="Name">Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.customer_id.customer_name} />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                                data-placement="top" title="" data-original-title="Address">Address</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.customer_id.address} />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                                data-placement="top" title="" data-original-title="Phne">Phone</label>
                                            <div class="col-sm-8">
                                                <input type="number" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.customer_id.phone} />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                                data-placement="top" title="" data-original-title="Email">Email</label>
                                            <div class="col-sm-8">
                                                <input type="email" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.customer_id.email} />
                                            </div>
                                        </div>
                                    </form>

                                    <div class="po-details merged-txtfields mt-3">
                                        <label class="row"><b>Buyer</b></label>

                                        <form>

                                            <div class="form-group row">
                                                <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                                    data-placement="top" title="" data-original-title="Name">Requester</label>
                                                <div class="col-sm-8">
                                                    <input type="number" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.created_by} />
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                                    data-placement="top" title="" data-original-title="Address">PR Number</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.poDetails.boq_id.boq_number} />
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex flex-row table-list-darkheading mt-5">
                            <table class="table  table-striped table-bordered">
                                <thead>
                                    <tr scope="col">
                                        <th>Item Number</th>
                                        <th>Item Description</th>
                                        <th>Unit Price</th>
                                        <th>Quantity</th>
                                        <th>Total Price (Baht)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.poDetails.po_items.map(item => {
                                        return <tr scope="row">
                                            <td>{item.part_number ? item.part_number : ''}</td>
                                            <td>{item.sku_name}</td>
                                            <td>{Math.round(item.unit_price)}</td>
                                            <td>{Math.round(item.quantity)}</td>
                                            <td>{Math.round(item.total_price)}</td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>
                        </div>

                        <div class="row mt-5 mb-5 ">
                            <div class="po-details merged-txtfields  col-sm-12 col-md-4 pt-3">
                                <div class="d-flex flex-column remarks-col">
                                    <label><b>Remarks by Supplier</b></label>
                                    <textarea rows="3" cols="10"> Enter any remarks</textarea>
                                </div>
                            </div>
                            <div class="po-details merged-txtfields  col-sm-12 col-md-4 pt-3">
                                <div class="d-flex flex-column remarks-col">
                                    <label><b>Remarks by Buyer</b></label>
                                    <textarea rows="3" cols="10"> Enter any remarks</textarea>
                                </div>
                            </div>
                            <div class="po-details merged-txtfields col-sm-12 col-md-4 pt-3">
                                <form>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Total Amount"><b>Total Amount</b></label>
                                        <div class="col-sm-8">
                                            <input type="number" class="form-control" id="colFormLabel" placeholder="" readOnly value={Math.round(this.state.poDetails.total_price)} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="VAT"><b>VAT</b></label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title=""><b>Total with VAT</b></label>
                                        <div class="col-sm-8">
                                            <input type="number" class="form-control" id="colFormLabel" placeholder="" readOnly value={Math.round(this.state.poDetails.total_price)} />
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                }
            })()}
        </React.Fragment>);
    }
}

export default Podetails; 
