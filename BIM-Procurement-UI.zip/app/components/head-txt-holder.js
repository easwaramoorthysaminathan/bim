import React, { Component } from "react";
class HeadTxt extends Component {
  render() {
    return (
      <div class="head-txt-sec d-flex justify-content-between p-3">
        <h3 class="align-self-center text-uppercase "></h3>
        <nav aria-label="breadcrumb" class="align-self-center">
          <ol class="breadcrumb bg-none align-self-center">
            <li class="breadcrumb-item">
              <a href="home">
                <i class="fas fa-home" />
                Home
              </a>
            </li>

            <li class="breadcrumb-item active" aria-current="page">
              Dashboard
            </li>
          </ol>
        </nav>
      </div>
    );
  }
}

export default HeadTxt;
