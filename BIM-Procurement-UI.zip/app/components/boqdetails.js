import React from "react";
import { BASE_API_URL, BASE_API_URL2, MATHCER_API_URL } from "../utils/constants";

class Boqdetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedBOQ: null,
            selectedPR: null,
            props: props,
            totalCost: 0,
            boqDetails: { boq_items: [] }
        };
        this.getBOQDetails = this.getBOQDetails.bind(this);
        this.onApproveClick = this.onApproveClick.bind(this);
        this.onSubmitApproveClick = this.onSubmitApproveClick.bind(this);
        this.onMapItemsClick = this.onMapItemsClick.bind(this);
    }
    onApproveClick() {
        //localhost:8080/match?boqid=Boq-19
        var data = {
            "entity_type_id": "BOQ",
            "entity_id": this.props.selectedBOQForEdit,
            "status": "Approved",
            "approved_by": "Supervisor1",
            "comments": "Approved"
        }
        const boqdata = new FormData();
        boqdata.append('boq', this.props.selectedBOQForEdit);
        var self = this;
        fetch(BASE_API_URL + "/approvals", { method: 'POST', body: JSON.stringify(data) })
            .then(
                function () {
                    fetch(BASE_API_URL + "boq/" + self.props.selectedBOQForEdit, { method: 'PUT', body: JSON.stringify({ 'status': 'approved', "approved_by": "Supervisor1", 'updated_at': '2018-11-08 12:10:12' }) })
                        .then(
                            function () {
                                fetch(BASE_API_URL2 + "/purchase_order.php", { method: 'POST', body: boqdata }).then(function () {
                                    self.getBOQDetails();
                                }).catch(function (error) {
                                    self.getBOQDetails();
                                });

                            }
                        ).catch(function (error) {
                            self.getBOQDetails();
                        });
                }
            ).catch(function (error) {
                fetch(BASE_API_URL + "boq/" + self.props.selectedBOQForEdit, { method: 'PUT', body: JSON.stringify({ 'status': 'approved', "approved_by": "Supervisor1", 'updated_at': '2018-11-08 12:10:12' }) })
                    .then(
                        function () {
                            fetch(BASE_API_URL2 + "/purchase_order.php", { method: 'POST', body: boqdata }).then(function () {
                                self.getBOQDetails();
                            }).catch(function (error) {
                                self.getBOQDetails();
                            });

                        }
                    ).catch(function (error) {
                        fetch(BASE_API_URL2 + "/purchase_order.php", { method: 'POST', body: boqdata }).then(function () {
                            self.getBOQDetails();
                        }).catch(function (error) {
                            self.getBOQDetails();
                        });

                    });
            })
    }

    onSubmitApproveClick() {

        fetch(BASE_API_URL + "boq/" + this.props.selectedBOQForEdit, { method: 'PUT', body: JSON.stringify({ 'status': 'pending_approval', 'updated_at': '2018-11-08 12:10:12' }) })
            .then(
                function () {
                    this.getBOQDetails();
                }
            )
    }
    onMapItemsClick() {
        var self = this;
        fetch(MATHCER_API_URL + "/match?boqid=" + this.props.selectedBOQForEdit)
            .then(function () {
                fetch(BASE_API_URL + "boq/" + this.props.selectedBOQForEdit, { method: 'PUT', body: JSON.stringify({ 'status': 'matched' }) })
                    .then(
                        function () {
                            this.getBOQDetails();
                        }
                    )
                // this.getBOQDetails();
            }
            ).catch(function (error) {
                self.getBOQDetails();
            })
    }
    getBOQDetails() {
        fetch(BASE_API_URL + "boq/" + this.props.selectedBOQForEdit + "?join=project&join=boq_items")
            .then(res => res.json())
            .then(
                (result) => {
					var obj = [...result.boq_items];
					obj.sort((a,b) => a.match_status - b.match_status);
					console.log(obj);
					result.boq_items = obj;
                    this.setState({
                        isLoaded: true,
                        boqDetails: result,
                        totalCost: Math.round(result.boq_items.reduce(function (cnt, o) { return cnt + o.total_price; }, 0))
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        boqDetails: {},
                        error
                    });
                }
            )
    }
    componentDidMount() {
        this.getBOQDetails();
    }
    render() {
        return (<React.Fragment>
            {(() => {
                if (this.state.boqDetails && this.state.boqDetails.project_id) {
                    return <div class="tab-pane fade active show" id="nav-boq" role="tabpanel" aria-labelledby="nav-boq-tab">
                        <div class="d-flex flex-row row">
                            <div class="pr-details col-6">
                                <form>
                                    <div class="form-group row">
                                        <label for="boq_number" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project Name">BOQ Number</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="boq_number" placeholder="" readOnly value={this.state.boqDetails.boq_number} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="project_number" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project ID">Project
                            ID</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="project_number" placeholder="" readOnly value={this.state.boqDetails.project_id.project_number} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="project_name" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project Name">Project Name</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="project_name" placeholder="" readOnly value={this.state.boqDetails.project_id.description} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="created_at" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Date Created">Date Created</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="created_at" placeholder="" readOnly value={this.state.boqDetails.created_at} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Date Approved">Date Approved</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.boqDetails.status == 'approved' ? this.state.boqDetails.updated_at : ''} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="status" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="BOQ Status">BOQ Status</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="status" placeholder="" readOnly value={this.state.boqDetails.status} />
                                        </div>
                                    </div>

                                </form>
                            </div>

                            <div class="status-container col-6 ext-head-tab table-list-lightheading ">
                                <div class="p-3 ext-head bg-red border-bottom"><b>BOQ Status: {this.state.boqDetails.status}</b></div>
                                <div class="p-3 ext-head">
                                    <form>
                                        <div class="form-group d-flex mb-0">
                                            <label for="inputEmail3" class="col-form-label"><b>Approver Level :</b></label>
                                            <div class="">
                                                <select class="form-control select2-combo" id="exampleFormControlSelect1">
                                                    <option>All Categories</option>
                                                    <option>All Categories</option>
                                                </select>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <table class="table table-bordered table-striped ">

                                    <thead>
                                        <tr>
                                            <th scope="col">Approvers</th>
                                            <th scope="col">Date of Action</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td scope="row">
                                                <select class="form-control plain" id="exampleFormControlSelect1">
                                                    <option>John A</option>
                                                </select></td>
                                            <td></td>
                                            <td>{this.state.boqDetails.status == 'approved' ? this.state.boqDetails.status : ''}</td>
                                            <td>
                                                <button style={{ display: this.state.boqDetails.status == 'pending_approval' ? 'block' : 'none' }} class="btn btn-success btn-sm-width" onClick={this.onApproveClick.bind(this)}>Approve</button> <button style={{ display: this.state.boqDetails.status == 'pending_approval' ? 'block' : 'none' }} class="btn btn-danger btn-sm-width">Reject</button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td scope="row"></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>

                                    </tbody>
                                </table>

                            </div>


                        </div>

                        <div class=" table-list-darkheading ">
                            <div class="grandtotal   d-flex  justify-content-between ">
                                <div class="button-holder">
                                    <button class="btn btn-secondary" style={{ display: this.state.boqDetails.status == 'pending_approval' || this.state.boqDetails.status == 'approved' ? 'block' : 'block' }} disabled={this.state.boqDetails.status == 'Mathced'} onClick={this.onMapItemsClick.bind(this)} id="btn-mapitem">Map Items</button> &nbsp;
                                <button onClick={this.onApproveClick.bind(this)} style={{ display: this.state.boqDetails.status == 'matched' ? 'block' : 'none' }} disabled={this.state.boqDetails.status == 'pending_approval'} class="btn btn-secondary  btn-approval" disabled="">Submit for Approval</button>
                                </div>

                                <div class="form-group d-flex justify-content-end">
                                    <label for="colFormLabel" class=" col-form-label text-left" data-toggle="tooltip" data-placement="top" title="" data-original-title="Project Name"><b>Grand Total Price:</b></label>
                                    <div class="">
                                        <input type="number" class="form-control" id="colFormLabel" placeholder="" value={this.state.totalCost} />
                                    </div>
                                </div>

                            </div>

                            <table class="table  table-striped table-bordered mb-0">
                                <thead>
                                    <tr scope="col">
                                        <th>Item ID</th>
                                        <th style={{ width: '20%' }}>Item Description</th>
                                        <th>Category</th>
                                        <th>Supplier</th>
                                        <th>Units</th>
                                        <th>Qty</th>
                                        <th>Match Status</th>
                                        <th>Price Per Unit</th>
                                        <th>Total Price (Baht)</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    {[].concat(this.state.boqDetails.boq_items).sort((a, b) => a.match_status > b.match_status).map(item => {
                                        return <tr scope="row" key={item.id}>
                                            <td>{item.part_number ? item.part_number : ''}</td>
                                            <td>{item.item_name}</td>
                                            <td>{item.category}</td>
                                            <td>{item.supplier ? item.supplier : ''}</td>
                                            <td>{item.unit}</td>
                                            <td>{Math.round(item.quantity)}</td>
                                            <td>{item.match_status}</td>
                                            <td>{Math.round(item.unit_price)}</td>
                                            <td>{Math.round(item.total_price)}</td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>



                        </div>

                    </div>
                }
            })()}
        </React.Fragment>);
    }
}

export default Boqdetails; 
