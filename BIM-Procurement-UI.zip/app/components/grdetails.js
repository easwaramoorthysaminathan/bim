import React from "react";
import { BASE_API_URL } from "../utils/constants";

class Grdetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedBOQ: null,
            selectedPR: null,
            props: props,
            grDetails: {}
        };
        this.onApproveClick = this.onApproveClick.bind(this);
        this.onMapItemsClick = this.onMapItemsClick.bind(this);
        this.onPoViewClick=this.onPoViewClick.bind(this);
    }
    onPoViewClick(){
      this.state.props.onPoViewClick(this.state.grDetails.poNumber.poNumber);
    }
    onApproveClick() { }
    onMapItemsClick() { }
    componentDidMount() {
        fetch(BASE_API_URL + "/goods_receipt?join=purchase_order&filter=goods_receipt_number,eq," + this.props.selectedGrForEdit + "&join=purchase_order&join=gr_items")
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        isLoaded: true,
                        grDetails: result.records[0]
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        grDetails: {},
                        error
                    });
                }
            )
    }
    render() {
        return (<React.Fragment>
            {(() => {
                if (this.state.grDetails && this.state.grDetails.poNumber) {
                    return <div class="tab-pane fade show active" id="nav-editpo" role="tabpanel" aria-labelledby="nav-editpo-tab">
                    <div class="row mr-0 ml-0 bg-grey-light p-3 border">
                      <div class="po-details   col-sm-12 col-md-6 pt-3">
                        <form>
  
                          <div class="form-group row">
                            <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                              data-placement="top" title="" data-original-title="PO Number">PO Number</label>
                            <div class="col-sm-8">
                              <input type="text" class="form-control" id="colFormLabel" placeholder="" value={this.state.grDetails.poNumber.poNumber}/>
                            </div>
                          </div>
                          <div class="form-group row">
                            <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                              data-placement="top" title="" data-original-title="Supplier Name">Supplier Name</label>
                            <div class="col-sm-8">
                              <input type="text" class="form-control" id="colFormLabel" placeholder="" value={this.state.grDetails.poNumber.supplier}/>
                            </div>
                          </div>
                          <div class="form-group row">
                            <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                              data-placement="top" title="" data-original-title="Date Received">Date Received</label>
                            <div class="col-sm-8">
                              <input type="date" class="form-control" id="colFormLabel" placeholder="" value={this.state.grDetails.date_received}/>
                            </div>
                          </div>
                          <div class="form-group row">
                            <label for="colFormLabel" class="col-sm-4 col-form-label text-left" data-toggle="tooltip"
                              data-placement="top" title="" data-original-title="Site Name">Site Name</label>
                            <div class="col-sm-8">
                              <input type="text" class="form-control" id="colFormLabel" placeholder="" value={this.state.grDetails.site_name}/>
                            </div>
                          </div>
  
  
  
                        </form>
  
  
  
                        <div class="pt-3 d-flex justify-content-end"><button class="btn btn-red pr-5 pl-5 mr-1">Save</button>
                          <button class="
                            btn btn-primary pr-5 pl-5">Cancel</button></div>
  
  
  
  
  
  
  
  
  
  
  
  
                      </div>
                      <div class="col-sm-12 col-md-6 pt-3">
                        <button class="btn btn-outline-light  pl-5 pr-5">Search</button><button class="btn btn-outline-light  pl-5 pr-5 ml-3">View
                          PO</button>
                      </div>
                    </div>
                    <div class=" table-list-darkheading mt-1 ">
                      <div class="add-del-panel  d-flex flex-row pt-5 pb-1 justify-content-between">
                        <div class="button-holder">
                          <button class="btn btn-secondary ">AddRows</button>
                          <button class="btn btn-secondary  ">Delete</button></div>
  
                      </div>
  
                      <table class="table  table-striped table-bordered">
                        <thead>
                          <tr scope="col">
                            <th>Item Number</th>
                            <th>Item Description</th>
                            <th>Qty Ordered</th>
                            <th>Qty Shipped</th>
                            <th>Qty Accepted</th>
                            <th>Qty Rejected</th>
                            <th>Batch Number</th>
                            <th>Comments</th>
                          </tr>
                        </thead>
                        <tbody>
                        {this.state.grDetails.gr_items.map(item => {
                                        return <tr scope="row">
                                            <td>{item.part_number ? item.part_number : ''}</td>
                                            <td>{item.sku_name}</td>
                                            <td>{item.quantity}</td>
                                            <td><input type="text" value={item.received_quantity}/></td>
                                            <td><input type="text" value={item.accepted_quantity}/></td>
                                            <td><input type="text" value={item.rejected_quantity}/></td>
                                            <td>{item.batch}</td>
                                            <td>{item.comment}</td>
                                        </tr>
                                    })}
                        </tbody>
                      </table>
  
  
  
                    </div>
                    <div class="d-flex flex-column remarks-col mt-3">
                      <label><b>Remarks</b></label>
                      <textarea rows="8" cols="50"> Enter any remarks</textarea>
                    </div>
  
  
  
  
  
                  </div>
                }
            })()}
        </React.Fragment>);
    }
}

export default Grdetails;