import React from "react";
import { BASE_API_URL, BASE_API_URL2 } from "../utils/constants";

class Prdetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedBoqForEdit: this.props.selectedBOQForEdit,
            selectedBOQ: null,
            selectedPR: null,
            projectId: null,
            props: props,
            boqDetails: { boq_items: [] }
        };
        this.onSaveClick = this.onSaveClick.bind(this);
        this.onProjectIdChange = this.onProjectIdChange.bind(this);
        this.onMapItemsClick = this.onMapItemsClick.bind(this);
        this.onFileChange = this.onFileChange.bind(this);
        this.onUploadClick = this.onUploadClick.bind(this);
        this.getPrDetails = this.getPrDetails.bind(this);
    }
    onFileChange() {
        this.setState({ 'fileName': this.uploadInput.files[0].name });
    }
    onUploadClick() {
        this.setState({ uploadInProgress: true });
        const data = new FormData();
        data.append('fileToUpload', this.uploadInput.files[0]);
        // data.append('project_id', this.state.projectId);
        // data.append('customer_id', 1);
        data.append('boq_number', this.state.selectedBoqForEdit);
        var self = this;
        fetch(BASE_API_URL2 + '/uploadpr.php', {
            method: 'POST',
            body: data,
        }).then(function () {
            self.setState({ uploadInProgress: false });
            self.getPrDetails();
        }).catch(function (error) {
            self.setState({ uploadInProgress: false });
            self.getPrDetails();
        });
    }
    onProjectIdChange() {
        this.setState({ projectId: event.target.value });
    }
    onSaveClick() {
        var data = {
            "entity_type_id": "PR",
            "customer_id": 1,
            "project_id": this.state.projectId,
            "status": "pending_approval"
        }
        fetch(BASE_API_URL + "/boq", { method: 'POST', body: JSON.stringify(data) })
    }
    onMapItemsClick() { }
    componentDidMount() {
        this.getPrDetails();
    }
    getPrDetails() {
        if (this.state.selectedBoqForEdit == 'Create PR') {
            this.setState({
                isLoaded: true,
                boqDetails: { project_id: {}, boq_items: [] }
            });
        } else {
            fetch(BASE_API_URL + "boq/" + this.state.selectedBoqForEdit + "?join=project&join=boq_items")
                .then(res => res.json())
                .then(
                    (result) => {
                        this.setState({
                            isLoaded: true,
                            boqDetails: result
                        });
                    },
                    // Note: it's important to handle errors here
                    // instead of a catch() block so that we don't swallow
                    // exceptions from actual bugs in components.
                    (error) => {
                        this.setState({
                            isLoaded: true,
                            boqDetails: {},
                            error
                        });
                    }
                )
        }
    }
    render() {
        return (<React.Fragment>
            {(() => {
                if (this.state.boqDetails && this.state.boqDetails.project_id) {
                    return <div class="tab-pane fade show active" id="nav-pr" role="tabpanel" aria-labelledby="nav-pr-tab">
                        <div class="d-flex flex-row border pt-5 pb-5 bg-grey-light">
                            <div class="pr-details col-6 border-right">
                                <form>

                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-3 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project Name">PR Number</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="colFormLabel" readOnly placeholder="" value={this.state.boqDetails.boq_number} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-3 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project ID">Project
                            ID</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" onChange={this.onProjectIdChange} value={this.state.boqDetails.project_id.project_number} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-3 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project Name">Project Name</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.boqDetails.project_id.description} />
                                        </div>
                                    </div>
                                </form>
                                <div class="d-flex justify-content-end mt-4">
                                    <button class="btn btn-red ml-1" onClick={this.onSaveClick.bind(this)}>Save</button>
                                    <button class="btn btn-primary ml-1">Cancel</button>
                                </div>
                                {/* <div class="d-flex justify-content-end mt-4"><button class="btn btn-red ml-1">Submit</button>
                                    <button class="btn btn-red ml-1">Save</button>
                                    <button class="btn btn-primary ml-1">Cancel</button>
                                </div> */}

                            </div>

                            <div class="col-6">
                                <div class="border flex-row">
                                    <h3 class="d-block p-2 bg-grey ">Add Items to PR</h3>
                                    <div class=" p-3 bg-white">
                                        <a style={{ display: this.state.selectedTab == 'pr' ? 'block' : 'block', width: '140px', color: '#fff' }} target="_blank" href="http://localhost:3001/PR_Template.xlsx" class="btn btn-red">Download Template</a>
                                        <hr />
                                        <div class="input-group mb-3">
                                            <div class="custom-file">
                                                <input ref={(ref) => { this.uploadInput = ref; }} onChange={this.onFileChange} type="file" class="custom-file-input" id="inputGroupFile02" />
                                                <label class="custom-file-label" for="inputGroupFile02" aria-describedby="inputGroupFileAddon02" style={{ color: this.state.fileName ? 'black' : '' }}> {this.state.fileName ? this.state.fileName : 'Choose File'}</label>
                                            </div>
                                        </div>
                                        <button class="btn btn-red mt-2" onClick={this.onUploadClick}>{this.state.uploadInProgress ? 'Uploading...' : 'Upload'}</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="add-del-panel  d-flex flex-row pt-5 justify-content-between">
                            <div class="button-holder">
                                <button class="btn btn-secondary ">AddRows</button>&nbsp;&nbsp;&nbsp;
                                <button class="btn btn-secondary  ">Delete</button></div>
                            <div class="grandtotal">
                                <div class="form-group d-flex justify-content-end mb-2">
                                    <label for="colFormLabel" class=" col-form-label text-left" data-toggle="tooltip"
                                        data-placement="top" title="" data-original-title="Project Name"><b>Grand Total Price:</b></label>
                                    <div class="">
                                        <input type="number" class="form-control" id="colFormLabel" placeholder="" value={this.state.boqDetails.boq_total_cost} />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex flex-row table-list-darkheading ">
                            <table class="table  table-striped table-bordered">
                                <thead>
                                    <tr scope="col">
                                        <th>
                                            <div class="text-center">
                                                <input type="checkbox" aria-label="Checkbox for following text input" />
                                            </div>
                                        </th>
                                        <th>Item ID</th>
                                        <th style={{ width: '20%' }}>Item Description</th>
                                        <th>Category</th>
                                        <th>Supplier</th>
                                        <th>Units</th>
                                        <th>Qty</th>
                                        <th>Price Per Unit</th>
                                        <th>Total Price (Baht)</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.boqDetails.boq_items.map(item => {
                                        return <tr scope="row">
                                            <td><input type="checkbox" aria-label="Checkbox for following text input" /></td>
                                            <td>{item.part_number ? item.part_number : ''}</td>
                                            <td>{item.item_name}</td>
                                            <td>{item.category}</td>
                                            <td>{item.supplier ? item.supplier : ''}</td>
                                            <td>{item.unit}</td>
                                            <td>{Math.round(item.quantity)}</td>
                                            <td>{Math.round(item.unit_price)}</td>
                                            <td>{Math.round(item.total_price)}</td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>


                        </div>
                    </div>
                }
            })()}
        </React.Fragment>);
    }
}

export default Prdetails; 