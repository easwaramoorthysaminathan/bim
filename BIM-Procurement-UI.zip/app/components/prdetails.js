import React from "react";
import { BASE_API_URL } from "../utils/constants";

class Prdetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedBOQ: null,
            selectedPR: null,
            props: props,
            boqDetails: { boq_items: [] }
        };
        this.onApproveClick = this.onApproveClick.bind(this);
        this.onMapItemsClick = this.onMapItemsClick.bind(this);
    }
    onApproveClick() { }
    onMapItemsClick() { }
    componentDidMount() {
        if (this.props.selectedBOQForEdit == 'Create PR') {
            this.setState({
                isLoaded: true,
                boqDetails: { project_id: {}, boq_items: [] }
            });
        } else {
            fetch(BASE_API_URL + "boq/" + this.props.selectedBOQForEdit + "?join=project&join=boq_items")
                .then(res => res.json())
                .then(
                    (result) => {
                        this.setState({
                            isLoaded: true,
                            boqDetails: result
                        });
                    },
                    // Note: it's important to handle errors here
                    // instead of a catch() block so that we don't swallow
                    // exceptions from actual bugs in components.
                    (error) => {
                        this.setState({
                            isLoaded: true,
                            boqDetails: {},
                            error
                        });
                    }
                )
        }
    }
    render() {
        return (<React.Fragment>
            {(() => {
                if (this.state.boqDetails && this.state.boqDetails.project_id) {
                    return <div class="tab-pane fade show active" id="nav-pr" role="tabpanel" aria-labelledby="nav-pr-tab">
                        <div class="d-flex flex-row border pt-5 pb-5 bg-grey-light">
                            <div class="pr-details col-6 border-right">
                                <form>

                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-3 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project Name">PR Number</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="colFormLabel" readOnly placeholder="" value={this.state.boqDetails.boq_number} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-3 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project ID">Project
                            ID</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" value={this.state.boqDetails.project_id.project_number} />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabel" class="col-sm-3 col-form-label text-left" data-toggle="tooltip"
                                            data-placement="top" title="" data-original-title="Project Name">Project Name</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="colFormLabel" placeholder="" readOnly value={this.state.boqDetails.project_id.description} />
                                        </div>
                                    </div>
                                </form>
                                <div class="d-flex justify-content-end mt-4">
                                    <button class="btn btn-red ml-1">Save</button>
                                    <button class="btn btn-primary ml-1">Cancel</button>
                                </div>
                                {/* <div class="d-flex justify-content-end mt-4"><button class="btn btn-red ml-1">Submit</button>
                                    <button class="btn btn-red ml-1">Save</button>
                                    <button class="btn btn-primary ml-1">Cancel</button>
                                </div> */}

                            </div>

                            <div class="col-6">
                                <div class="border flex-row">
                                    <h3 class="d-block p-2 bg-grey ">Add Items to PR</h3>
                                    <div class=" p-3 bg-white">
                                        <button class="btn btn-red">Download Template</button>
                                        <hr />
                                        <div class="input-group mb-3">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="inputGroupFile02" />
                                                <label class="custom-file-label" for="inputGroupFile02" aria-describedby="inputGroupFileAddon02">Choose file</label>
                                            </div>
                                        </div>
                                        <button class="btn btn-red mt-2">Upload Template</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="add-del-panel  d-flex flex-row pt-5 justify-content-between">
                            <div class="button-holder">
                                <button class="btn btn-secondary ">AddRows</button>&nbsp;&nbsp;&nbsp;
                                <button class="btn btn-secondary  ">Delete</button></div>
                            <div class="grandtotal">
                                <div class="form-group d-flex justify-content-end mb-2">
                                    <label for="colFormLabel" class=" col-form-label text-left" data-toggle="tooltip"
                                        data-placement="top" title="" data-original-title="Project Name"><b>Grand Total Price:</b></label>
                                    <div class="">
                                        <input type="number" class="form-control" id="colFormLabel" placeholder="" value={this.state.boqDetails.boq_total_cost} />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex flex-row table-list-darkheading ">
                            <table class="table  table-striped table-bordered">
                                <thead>
                                    <tr scope="col">
                                        <th>
                                            <div class="text-center">
                                                <input type="checkbox" aria-label="Checkbox for following text input" />
                                            </div>
                                        </th>
                                        <th>Item ID</th>
                                        <th style={{ width: '20%' }}>Item Description</th>
                                        <th>Category</th>
                                        <th>Supplier</th>
                                        <th>Units</th>
                                        <th>Qty</th>
                                        <th>Price Per Unit</th>
                                        <th>Total Price (Baht)</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.boqDetails.boq_items.map(item => {
                                        return <tr scope="row">
                                            <td><input type="checkbox" aria-label="Checkbox for following text input" /></td>
                                            <td>{item.part_number ? item.part_number : ''}</td>
                                            <td>{item.item_name}</td>
                                            <td>{item.category}</td>
                                            <td>{item.supplier ? item.supplier : ''}</td>
                                            <td>{item.unit}</td>
                                            <td>{Math.round(item.quantity)}</td>
                                            <td>{Math.round(item.unit_price)}</td>
                                            <td>{Math.round(item.total_price)}</td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>


                        </div>
                    </div>
                }
            })()}
        </React.Fragment>);
    }
}

export default Prdetails; 