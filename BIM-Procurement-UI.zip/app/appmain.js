import "babel-polyfill";
import React from "react";
import ReactDOM from "react-dom";
import {
  HashRouter,
  BrowserRouter as Router,
  Route,
  Switch,
  Link,
  Redirect
} from "react-router-dom";
import Header from "components/header";
import Footer from "components/footer";
import LeftNav from "components/leftnav";
import HeadTxt from "components/head-txt-holder";
import SearchPanel from "components/search-panel";
import routes from "./routes";
window.app = {};
app.routes = routes;
import "assets/sass/main.scss";
import "assets/css/icomoon.css";

//import "assets/sass/home.scss";
//import 'assets/css/slick-carousel.css';
//import 'assets/css/offcanvas.css';
//import 'assets/css/inputrange.css';
//import $ from 'jquery';
import { loadableComp } from "utils/common";

//const history = createHistory();
/* window.addEventListener("beforeunload", (e) => 
{  
    var confirmationMessage = "\o/";

    (e || window.event).returnValue = confirmationMessage; //Gecko + IE
    return app.pendingActions?confirmationMessage:false;       
}); */

//window.$ = $;
//initApp();

const NoMatch = ({ location }) => <Redirect to="/home" />;
//const Header = ComponentWrapper(header);

class Main extends React.Component {
  constructor(props) {
    super(props);
    this.state = { appinit: false };
  }
  componentDidMount() {
    console.log(process.env.CONFIG_PATH + "-----Main mouted------");
  }
  componentDidUpdate() {
    console.log("-----Main updated------");
  }
  render() {
    //if(!this.state.appinit)  return <div>Loading.......</div>
    return (
      <React.Fragment>
        <Header />
        <main role="content" className="content-wrap">
          <div className="container">
            <div className="content-box">
              <LeftNav />
              <div className="content-panel pg-dashboard negative-mrgin">
                <HeadTxt />
                <SearchPanel />
                <div class="content-area dashboard-panel m-3">
                  <HashRouter>
                    <Switch>
                      {routes.map(route => {
                        let component = loadableComp(route.componentId);
                        return (
                          <Route
                            {...route}
                            key={route.name}
                            component={component}
                          />
                        );
                      })}
                      <Route component={NoMatch} />
                    </Switch>
                  </HashRouter>
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </React.Fragment>
    );
  }
}

ReactDOM.render(<Main />, document.getElementById("approot"));
